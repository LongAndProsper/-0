﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace deliver_management
{
    public partial class FormLogin : Form
    {
        public user user1;
        public FormLogin()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (checkinput()== true)
            {
                if (Login())
                {
                  user user1 = new user();
                    user1.userid = textBox1.Text.Trim();
                    user1.pwd= textBox2.Text.Trim();
           
                    MessageBox.Show("登陆成功");
                    Formmain frm = new Formmain();
                    frm.user2 = user1;
                    frm.Show();
                    this.Hide();
                }
                else
                    MessageBox.Show("登陆失败");
            }
           

        }
        //非空验证
        private bool checkinput()
        {
            if (textBox1.Text.Trim() == "" || textBox2.Text.Trim() == "")
            {
                MessageBox.Show("请输入用户名和密码");
                return false;
            }
            return true;
        }
        public bool Login()
        {
            bool flag = false;
            string name = textBox1.Text.Trim();
            string pwd = textBox2.Text.Trim();
            login LOGIN = new login();
            try
            {
                //创建sql语句
                string sql = string.Format("select* from members where m_phone='{0}' and m_password='{1}'", name, pwd);
                //commend工具
                SqlCommand cmd = new SqlCommand(sql, LOGIN.Connection);
                //打开连接
                LOGIN.OpenConnection();
                //执行
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read()) flag = true;
                //判断

            }
            catch (Exception ex)
            {
                MessageBox.Show("发生异常：" + ex.Message);
            }
            finally
            {
                LOGIN.CloseConnection();
            }
            return flag;
        }
        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

      

        private void button2_Click(object sender, EventArgs e)
        {
           Formsignup frm = new Formsignup();
            frm.Show();
            this.Hide();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
