﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace deliver_management
{
    public partial class Formmissionreleased : Form
    {
       public user user4;
        public Formmissionreleased()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int result;double k1 = 1, k2 = 0.8, k3 = 0.5,k4=0;
            login lo = new login();
            if (deliverytype.SelectedIndex == 0)
            {
            try
            {
                    string sql = string.Format(@"insert into orders(o_price ,r_num ,r_name ,r_phone ,d_address ,r_address ,r_datetime ,
                                        o_describe ,m_name ,m_phone,o_state ) values ('{0}','{1}','{2}','{3}','{4}','{5}',
                                    '{6}','{7}','{8}','{9}','{10}')", k1, takingnum.Text.Trim(), takingman.Text.Trim(), takingmanphone.Text.Trim(),
                                      deliveraddress.Text.Trim(), recievingaddress.Text.Trim(), datetime.Text.Trim(), describle.Text.Trim(), user4.username, user4.userid, k4);
                    SqlCommand cmd = new SqlCommand(sql, lo.Connection);
                lo.OpenConnection();
                result = cmd.ExecuteNonQuery();
                if (result > 0)
                {
                        DialogResult dr = MessageBox.Show("确定发布任务？", "提示", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                        if (dr == System.Windows.Forms.DialogResult.OK)
                        {
                            Formmain frm = new Formmain();
                            MessageBox.Show("任务发布成功！！！");
                            this.Hide();
                            frm.Show();
                        }
                    }
                else
                    MessageBox.Show("发布失败");
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            };
            }
           else  if (deliverytype.SelectedIndex == 1)
            {
                try
                {
                    string sql = string.Format(@"insert into orders(o_price ,r_num ,r_name ,r_phone ,d_address ,r_address ,r_datetime ,
                                        o_describe ,m_name ,m_phone,o_state ) values ('{0}','{1}','{2}','{3}','{4}','{5}',
                                    '{6}','{7}','{8}','{9}','{10}')", k2,takingnum.Text.Trim(), takingman.Text.Trim(), takingmanphone.Text.Trim(),
                                   deliveraddress.Text.Trim(), recievingaddress.Text.Trim(), datetime.Text.Trim(), describle.Text.Trim(), user4.username, user4.userid,k4);

              
                    SqlCommand cmd = new SqlCommand(sql, lo.Connection);
                    lo.OpenConnection();
                    result = cmd.ExecuteNonQuery();
                    if (result > 0)
                    {
                        DialogResult dr = MessageBox.Show("确定发布任务？", "提示", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                        if (dr == System.Windows.Forms.DialogResult.OK)
                        {
                            Formmain frm = new Formmain();
                            MessageBox.Show("任务发布成功！！！");
                            this.Hide();
                            frm.Show();
                        }
                    }
                    else
                        MessageBox.Show("发布失败");
                }
                catch (Exception ex)
                { 

                    MessageBox.Show(ex.Message);
                };
            }
           else if (deliverytype.SelectedIndex == 2)
            {
                    try
                {
                    string sql = string.Format(@"insert into orders(o_price ,r_num ,r_name ,r_phone ,d_address ,r_address ,r_datetime ,
                                        o_describe ,m_name ,m_phone,o_state ) values ('{0}','{1}','{2}','{3}','{4}','{5}',
                                    '{6}','{7}','{8}','{9}','{10}')", k3, takingnum.Text.Trim(), takingman.Text.Trim(), takingmanphone.Text.Trim(),
                                                      deliveraddress.Text.Trim(), recievingaddress.Text.Trim(), datetime.Text.Trim(), describle.Text.Trim(), user4.username, user4.userid, k4);


                    SqlCommand cmd = new SqlCommand(sql, lo.Connection);
                    lo.OpenConnection();
                    result = cmd.ExecuteNonQuery();
                    if (result > 0)
                    {
                        DialogResult dr = MessageBox.Show("确定发布任务？", "提示", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                        if (dr == System.Windows.Forms.DialogResult.OK)
                        {
                            Formmain frm = new Formmain();
                            MessageBox.Show("任务发布成功！！！");
                            this.Hide();
                            frm.Show();
                        }
                    }
                    else
                        MessageBox.Show("发布失败");
                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message);
                };
            }
            lo.CloseConnection();
          
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Formmain frm = new Formmain();
            frm.Show();
            this.Hide();
        }

        private void Formmissionreleased_Load(object sender, EventArgs e)
        {

        }
    }
}
