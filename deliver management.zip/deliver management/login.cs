﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
namespace deliver_management
{
   public class login
    {
        private string connString = @"Data Source=192.168.43.110;Initial Catalog=delivery;User Id=sa;Pwd=123";
        private SqlConnection connection;

        public SqlConnection Connection
        {
            get
            {
                if (connection == null)
                    connection = new SqlConnection(connString);
                return connection;
            }
     
        }
        //打开链接
        public void OpenConnection()
        {
            if (Connection.State == ConnectionState.Closed)
                Connection.Open();
            else if(Connection.State == ConnectionState.Broken)
            {
                Connection.Close();
                Connection.Open();
            }
        }
        //关闭数据库
        public void CloseConnection()
        {
            if (Connection.State == ConnectionState.Open|| Connection.State == ConnectionState.Broken)
                Connection.Close();
        }
    }
}
