﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Configuration;
using System.Collections;

namespace deliver_management
{
    public partial class Formmain : Form
    {
     DataSet ds = new DataSet();
        public user user2;
      
        public Formmain()
        {
            InitializeComponent();
        }
        //退出
        private void exit_Click(object sender, EventArgs e)
        {
            
        }

        private void pwdchanged_Click(object sender, EventArgs e)
        {
            changepwd frm1 = new changepwd();
            frm1.user3 = this.user2;
            frm1.Show();
        }

        private void copright_Click(object sender, EventArgs e)
        {
            Formcopright frm = new Formcopright();
            frm.ShowDialog();  
                }

        private void 关于我们ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void missionreleased_Click(object sender, EventArgs e)
        {
            Formmissionreleased frm = new Formmissionreleased();
            frm.user4 = this.user2;
            frm.Show();
            this.Hide();
        }

        private void 我的记录ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void exit_Click_1(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("确定退出当前帐号吗？", "提示", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (dr == System.Windows.Forms.DialogResult.OK)
            {
                Application.Exit();
            }
        }

        private void Formmain_Load(object sender, EventArgs e)
        {
         
          string sql = "select r_num as 取件号 ,d_address as 快递点 ,r_address as 收货地址 ,o_describe as 备注, r_datetime as 截止时间, o_price AS 金额 from orders where o_state=0";
            SqlConnectionStringBuilder scsb = new SqlConnectionStringBuilder();
            scsb.DataSource = "192.168.43.110";
            scsb.UserID = "sa";
            scsb.Password = "123";
            scsb.InitialCatalog = "delivery";
            SqlConnection conn = new SqlConnection(scsb.ToString());
            if (conn.State == System.Data.ConnectionState.Closed) conn.Open();
           // string sql = "select * from orders";
            SqlDataAdapter da = new SqlDataAdapter(sql, conn);
            DataSet ds = new DataSet();
            da.Fill(ds, "orders");
          // this. fliter(0);
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "orders";


        }

        private void 接受任务ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            receivemission frm = new receivemission();
            frm.user6 = this.user2;
            this.Hide();
            frm.Show();
        }
        public void selection()
        {
           
            login log = new login();
            DataSet ds = new DataSet();

            // string connString = @"Data Source=.;Initial Catalog=deliverymanagement;User Id=sa;Pwd=123";
            string sql = "select * from orders";

            try
            {
                SqlDataAdapter ada = new SqlDataAdapter(sql, log.Connection);
                ada.Fill(ds, "orders");
                this.dataGridView1.DataSource = this.ds.Tables["orders"];

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
              


        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnectionStringBuilder scsb = new SqlConnectionStringBuilder();
            scsb.DataSource = "192.168.43.110";
            scsb.UserID = "sa";
            scsb.Password = "123";
            scsb.InitialCatalog = "delivery";
            SqlConnection conn = new SqlConnection(scsb.ToString ());
            if (conn.State == System.Data.ConnectionState.Closed)   conn.Open();
            string sql = "select r_num as 取件号 ,d_address as 快递点 ,r_address as 收货地址 ,o_describe as 备注, r_datetime as 截止时间, o_price AS 金额, o_state AS [状态-已取件]  from orders";
            SqlDataAdapter da = new SqlDataAdapter(sql, conn);
            DataSet ds = new DataSet();
            da.Fill(ds, "orders");
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "orders";




        }

        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.ordersTableAdapter.FillBy(this.deliveryDataSet.orders);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }


    //s视图具有过滤筛选的方法
        public void fliter(int o_state)
        {
            DataView dv = new DataView();
            if (o_state == 0) dv.RowFilter = "状态-已取件='未取件'";
            else if(o_state==1)
                dv.RowFilter = "状态-已取件='派送中'";
            else
                dv.RowFilter = "状态-已取件='已完成'";
            dataGridView1.DataSource = dv;
    
        }

        private void mydelivering_Click(object sender, EventArgs e)
        {
            mydeliveringrecord frm = new mydeliveringrecord();
            frm.user5 = this.user2;
            frm.Show();
            this.Hide();
        }

        private void 联系我们ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            contactus frm = new contactus();
            frm.Show();
            this.Hide();
             }

        private void 我接受的ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            myreceive frm = new myreceive();
            frm.user7 = this.user2;
            frm.Show();
            this.Hide();
        }

        private void payment_Click(object sender, EventArgs e)
        {
            formpay frm = new formpay();
            this.Hide();
            frm.Show();
       

        }
    }
}
