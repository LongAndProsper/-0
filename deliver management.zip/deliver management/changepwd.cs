﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace deliver_management
{
    public partial class changepwd : Form
    {
        public user user3;
        public changepwd()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(checkpwd()==true)
            {
                int result;
                login lo = new login();
                string sql = string.Format(@"update members set m_password='{0}'where m_phone={1}", newpwd.Text.Trim(), user3.userid);
                try
                {
                    SqlCommand cmd = new SqlCommand(sql, lo.Connection);
                    lo.OpenConnection();
                   result= cmd.ExecuteNonQuery();
                    if (result > 0)
                    {
                        MessageBox.Show("更新成功");
                        this.Close();
                    }
                    else
                        MessageBox.Show("修改失败");
                }
                catch (Exception ex )
                {

                    MessageBox.Show(ex.Message);
                };
                
                lo.CloseConnection();
           
             

            }
            
        }
        public bool checkpwd()
        {
            if (oldpwd.Text.Trim() == "")
            {
                MessageBox.Show("请输入原密码");
                return false;
            }
            if (oldpwd.Text.Trim() != user3.pwd)
            {
                MessageBox.Show("原密码错误");
                return false;
            }
            if (textBox1.Text.Trim() == "")
            {
                MessageBox.Show("请输入新密码");
                return false;
            }
            if (okpwd.Text.Trim() == "")
            {
                MessageBox.Show("请再次输入新密码");
                return false;
            }
            if (textBox1.Text.Trim()!= okpwd.Text.Trim())
            {
                MessageBox.Show("两次密码不一致");
     
                return false;
            }
            else
                return true;
        }
        }
    }
