﻿namespace deliver_management
{
    partial class Formmain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Formmain));
            this.menu1 = new System.Windows.Forms.MenuStrip();
            this.服务大厅ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.missionreleased = new System.Windows.Forms.ToolStripMenuItem();
            this.接受任务ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.myrecord = new System.Windows.Forms.ToolStripMenuItem();
            this.mydelivering = new System.Windows.Forms.ToolStripMenuItem();
            this.我接受的ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.设置ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pwdchanged = new System.Windows.Forms.ToolStripMenuItem();
            this.exit = new System.Windows.Forms.ToolStripMenuItem();
            this.关于我们ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.联系我们ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copright = new System.Windows.Forms.ToolStripMenuItem();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.ordersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.deliveryDataSet = new deliver_management.deliveryDataSet();
            this.ordersTableAdapter = new deliver_management.deliveryDataSetTableAdapters.ordersTableAdapter();
            this.payment = new System.Windows.Forms.ToolStripMenuItem();
            this.menu1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ordersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.deliveryDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // menu1
            // 
            this.menu1.BackColor = System.Drawing.SystemColors.Control;
            this.menu1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible;
            this.menu1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menu1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.服务大厅ToolStripMenuItem,
            this.myrecord,
            this.设置ToolStripMenuItem,
            this.关于我们ToolStripMenuItem});
            this.menu1.Location = new System.Drawing.Point(0, 0);
            this.menu1.Name = "menu1";
            this.menu1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.menu1.Size = new System.Drawing.Size(1202, 32);
            this.menu1.TabIndex = 0;
            this.menu1.Text = "menuStrip1";
            // 
            // 服务大厅ToolStripMenuItem
            // 
            this.服务大厅ToolStripMenuItem.BackColor = System.Drawing.SystemColors.Control;
            this.服务大厅ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.missionreleased,
            this.接受任务ToolStripMenuItem});
            this.服务大厅ToolStripMenuItem.Name = "服务大厅ToolStripMenuItem";
            this.服务大厅ToolStripMenuItem.Size = new System.Drawing.Size(94, 28);
            this.服务大厅ToolStripMenuItem.Text = "服务大厅";
            // 
            // missionreleased
            // 
            this.missionreleased.Name = "missionreleased";
            this.missionreleased.Size = new System.Drawing.Size(210, 30);
            this.missionreleased.Text = "发布任务";
            this.missionreleased.Click += new System.EventHandler(this.missionreleased_Click);
            // 
            // 接受任务ToolStripMenuItem
            // 
            this.接受任务ToolStripMenuItem.Name = "接受任务ToolStripMenuItem";
            this.接受任务ToolStripMenuItem.Size = new System.Drawing.Size(210, 30);
            this.接受任务ToolStripMenuItem.Text = "领取任务";
            this.接受任务ToolStripMenuItem.Click += new System.EventHandler(this.接受任务ToolStripMenuItem_Click);
            // 
            // myrecord
            // 
            this.myrecord.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mydelivering,
            this.我接受的ToolStripMenuItem});
            this.myrecord.Name = "myrecord";
            this.myrecord.Size = new System.Drawing.Size(94, 28);
            this.myrecord.Text = "我的记录";
            this.myrecord.Click += new System.EventHandler(this.我的记录ToolStripMenuItem_Click);
            // 
            // mydelivering
            // 
            this.mydelivering.Name = "mydelivering";
            this.mydelivering.Size = new System.Drawing.Size(210, 30);
            this.mydelivering.Text = "我发布的";
            this.mydelivering.Click += new System.EventHandler(this.mydelivering_Click);
            // 
            // 我接受的ToolStripMenuItem
            // 
            this.我接受的ToolStripMenuItem.Name = "我接受的ToolStripMenuItem";
            this.我接受的ToolStripMenuItem.Size = new System.Drawing.Size(210, 30);
            this.我接受的ToolStripMenuItem.Text = "我接受的";
            this.我接受的ToolStripMenuItem.Click += new System.EventHandler(this.我接受的ToolStripMenuItem_Click);
            // 
            // 设置ToolStripMenuItem
            // 
            this.设置ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pwdchanged,
            this.exit,
            this.payment});
            this.设置ToolStripMenuItem.Name = "设置ToolStripMenuItem";
            this.设置ToolStripMenuItem.Size = new System.Drawing.Size(58, 28);
            this.设置ToolStripMenuItem.Text = "设置";
            // 
            // pwdchanged
            // 
            this.pwdchanged.Name = "pwdchanged";
            this.pwdchanged.Size = new System.Drawing.Size(210, 30);
            this.pwdchanged.Text = "修改密码";
            this.pwdchanged.Click += new System.EventHandler(this.pwdchanged_Click);
            // 
            // exit
            // 
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(210, 30);
            this.exit.Text = "退出";
            this.exit.Click += new System.EventHandler(this.exit_Click_1);
            // 
            // 关于我们ToolStripMenuItem
            // 
            this.关于我们ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.联系我们ToolStripMenuItem,
            this.copright});
            this.关于我们ToolStripMenuItem.Name = "关于我们ToolStripMenuItem";
            this.关于我们ToolStripMenuItem.Size = new System.Drawing.Size(94, 28);
            this.关于我们ToolStripMenuItem.Text = "关于我们";
            this.关于我们ToolStripMenuItem.Click += new System.EventHandler(this.关于我们ToolStripMenuItem_Click);
            // 
            // 联系我们ToolStripMenuItem
            // 
            this.联系我们ToolStripMenuItem.Name = "联系我们ToolStripMenuItem";
            this.联系我们ToolStripMenuItem.Size = new System.Drawing.Size(210, 30);
            this.联系我们ToolStripMenuItem.Text = "联系我们";
            this.联系我们ToolStripMenuItem.Click += new System.EventHandler(this.联系我们ToolStripMenuItem_Click);
            // 
            // copright
            // 
            this.copright.Name = "copright";
            this.copright.Size = new System.Drawing.Size(210, 30);
            this.copright.Text = "版本";
            this.copright.Click += new System.EventHandler(this.copright_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToOrderColumns = true;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(0, 35);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowTemplate.Height = 30;
            this.dataGridView1.Size = new System.Drawing.Size(1198, 472);
            this.dataGridView1.TabIndex = 1;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(509, 532);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(143, 34);
            this.button1.TabIndex = 2;
            this.button1.Text = "刷新";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // ordersBindingSource
            // 
            this.ordersBindingSource.DataMember = "orders";
            this.ordersBindingSource.DataSource = this.deliveryDataSet;
            // 
            // deliveryDataSet
            // 
            this.deliveryDataSet.DataSetName = "deliveryDataSet";
            this.deliveryDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // ordersTableAdapter
            // 
            this.ordersTableAdapter.ClearBeforeFill = true;
            // 
            // payment
            // 
            this.payment.Name = "payment";
            this.payment.Size = new System.Drawing.Size(210, 30);
            this.payment.Text = "充值";
            this.payment.Click += new System.EventHandler(this.payment_Click);
            // 
            // Formmain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1202, 578);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.menu1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Formmain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "deliver management";
            this.Load += new System.EventHandler(this.Formmain_Load);
            this.menu1.ResumeLayout(false);
            this.menu1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ordersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.deliveryDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menu1;
        private System.Windows.Forms.ToolStripMenuItem 服务大厅ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem myrecord;
        private System.Windows.Forms.ToolStripMenuItem 设置ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 关于我们ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pwdchanged;
        private System.Windows.Forms.ToolStripMenuItem 联系我们ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copright;
        private System.Windows.Forms.ToolStripMenuItem missionreleased;
        private System.Windows.Forms.ToolStripMenuItem 接受任务ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exit;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ToolStripMenuItem mydelivering;
        private System.Windows.Forms.ToolStripMenuItem 我接受的ToolStripMenuItem;
        private deliveryDataSet deliveryDataSet;
        private System.Windows.Forms.BindingSource ordersBindingSource;
        private deliveryDataSetTableAdapters.ordersTableAdapter ordersTableAdapter;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ToolStripMenuItem payment;
    }
}