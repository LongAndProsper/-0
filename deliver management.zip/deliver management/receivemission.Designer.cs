﻿namespace deliver_management
{
    partial class receivemission
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(receivemission));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.checkbox = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.r_num = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.d_address = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.r_name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.r_phone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.r_address = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.o_describe = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.r_datetime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.o_price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToOrderColumns = true;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.checkbox,
            this.r_num,
            this.d_address,
            this.r_name,
            this.r_phone,
            this.r_address,
            this.o_describe,
            this.r_datetime,
            this.o_price});
            this.dataGridView1.Location = new System.Drawing.Point(-3, 77);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 30;
            this.dataGridView1.Size = new System.Drawing.Size(1125, 434);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.dataGridView1.CurrentCellChanged += new System.EventHandler(this.dataGridView1_CurrentCellChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(399, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(279, 30);
            this.label1.TabIndex = 2;
            this.label1.Text = "领 取 任 务 平 台";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // checkbox
            // 
            this.checkbox.FalseValue = "false";
            this.checkbox.HeaderText = "是否领取";
            this.checkbox.IndeterminateValue = "2";
            this.checkbox.Name = "checkbox";
            this.checkbox.TrueValue = "true";
            this.checkbox.Width = 86;
            // 
            // r_num
            // 
            this.r_num.DataPropertyName = "r_num";
            this.r_num.HeaderText = "取件号";
            this.r_num.Name = "r_num";
            this.r_num.Width = 98;
            // 
            // d_address
            // 
            this.d_address.DataPropertyName = "d_address";
            this.d_address.HeaderText = "快递点";
            this.d_address.Name = "d_address";
            this.d_address.Width = 98;
            // 
            // r_name
            // 
            this.r_name.DataPropertyName = "r_name";
            this.r_name.HeaderText = "收件人";
            this.r_name.Name = "r_name";
            this.r_name.Width = 98;
            // 
            // r_phone
            // 
            this.r_phone.DataPropertyName = "r_phone";
            this.r_phone.HeaderText = "联系电话";
            this.r_phone.Name = "r_phone";
            this.r_phone.Width = 116;
            // 
            // r_address
            // 
            this.r_address.DataPropertyName = "r_address";
            this.r_address.HeaderText = "收货地址";
            this.r_address.Name = "r_address";
            this.r_address.Width = 116;
            // 
            // o_describe
            // 
            this.o_describe.DataPropertyName = "o_describe";
            this.o_describe.HeaderText = "备注";
            this.o_describe.Name = "o_describe";
            this.o_describe.Width = 80;
            // 
            // r_datetime
            // 
            this.r_datetime.DataPropertyName = "r_datetime";
            this.r_datetime.HeaderText = "截止时间";
            this.r_datetime.Name = "r_datetime";
            this.r_datetime.Width = 116;
            // 
            // o_price
            // 
            this.o_price.DataPropertyName = "o_price";
            this.o_price.HeaderText = "金额";
            this.o_price.Name = "o_price";
            this.o_price.Width = 80;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("宋体", 42F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button1.Location = new System.Drawing.Point(-3, -27);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(64, 78);
            this.button1.TabIndex = 3;
            this.button1.Text = "⬅";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // receivemission
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1134, 556);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "receivemission";
            this.Load += new System.EventHandler(this.receivemission_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn checkbox;
        private System.Windows.Forms.DataGridViewTextBoxColumn r_num;
        private System.Windows.Forms.DataGridViewTextBoxColumn d_address;
        private System.Windows.Forms.DataGridViewTextBoxColumn r_name;
        private System.Windows.Forms.DataGridViewTextBoxColumn r_phone;
        private System.Windows.Forms.DataGridViewTextBoxColumn r_address;
        private System.Windows.Forms.DataGridViewTextBoxColumn o_describe;
        private System.Windows.Forms.DataGridViewTextBoxColumn r_datetime;
        private System.Windows.Forms.DataGridViewTextBoxColumn o_price;
        private System.Windows.Forms.Button button1;
    }
}