﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace deliver_management
{
    public partial class Formsignup : Form
    {
        public Formsignup()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btnsignup_Click(object sender, EventArgs e)
        {
            if (checkpwd() == true)
            {
                int result;
                login lo = new login();
                string sql = string.Format(@"insert into members values ('{0}','{1}','{2}')",name.Text.Trim(),phone.Text.Trim(),inputpwd.Text.Trim());
                try
                {
                    SqlCommand cmd = new SqlCommand(sql, lo.Connection);
                    lo.OpenConnection();
                    result = cmd.ExecuteNonQuery();
                    if (result > 0)
                    {
                        user user0 = new user();
                        user0.username = name.Text.Trim();
                        user0.userid = phone.Text.Trim();
                        user0.pwd = inputpwd.Text.Trim();
                        MessageBox.Show("注册成功");
                        FormLogin frm = new FormLogin();
                        frm.user1 = user0;
                        frm.Show();
                        this.Hide();

                    }
                    else
                        MessageBox.Show("注册失败");
                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message);
                };

                lo.CloseConnection();



            }
           
        }
        public bool checkpwd()
        {
            if (phone.Text.Trim() == "")
            {
                MessageBox.Show("请输入电话号码");
                return false;
            }
         
            if (name.Text.Trim() == "")
            {
                MessageBox.Show("请输入姓名");
                return false;
            }
            if (inputpwd.Text.Trim() == "")
            {
                MessageBox.Show("请输入密码");
                return false;
            }
            if (okpwd.Text.Trim() == "")
            {
                MessageBox.Show("请再次输入密码");
                return false;
            }
            if (okpwd.Text.Trim() != inputpwd.Text.Trim())
            {
                MessageBox.Show("两次密码不一致");
                return false;
            }
            else
                return true;
        }
    }
}
