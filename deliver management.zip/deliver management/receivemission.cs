﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace deliver_management
{
    public partial class receivemission : Form
    {
        public user user6;
        public receivemission()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void receivemission_Load(object sender, EventArgs e)
        {
            string sql = "select r_num  ,d_address  ,r_name ,r_phone,r_address ,o_describe, r_datetime, o_price  from orders where o_state=0";
            SqlConnectionStringBuilder scsb = new SqlConnectionStringBuilder();
            scsb.DataSource = "192.168.43.110";
            scsb.UserID = "sa";
            scsb.Password = "123";
            scsb.InitialCatalog = "delivery";
            SqlConnection conn = new SqlConnection(scsb.ToString());
            if (conn.State == System.Data.ConnectionState.Closed) conn.Open();
            // string sql = "select * from orders";
            SqlDataAdapter da = new SqlDataAdapter(sql, conn);
            DataSet ds = new DataSet();
            da.Fill(ds, "orders");
            // this. fliter(0);
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "orders";
        }

       public void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
          

            if (e.RowIndex !=-1&&e.ColumnIndex != -1)
            {
                if ((bool)dataGridView1.Rows[e.RowIndex].Cells[0].EditedFormattedValue == true)
                {
                    int result;
                    this.dataGridView1.Rows[e.RowIndex].Cells[0].Value =false;
                    DialogResult dr = MessageBox.Show("确定接受该任务？", "提示", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                    if (dr == System.Windows.Forms.DialogResult.OK)
                    {
                        login lo = new login();
                        string sql = string.Format(@"update orders set d_phone='{0}',o_state='{1}' where r_num='{2}'", user6.userid, 1, dataGridView1.Rows[e.RowIndex].Cells[1].EditedFormattedValue);
                        try
                        {
                            SqlCommand cmd = new SqlCommand(sql, lo.Connection);
                            lo.OpenConnection();
                            result = cmd.ExecuteNonQuery();
                            if (result > 0)
                            {
                                MessageBox.Show("接受成功");
                                receivemission frm = new receivemission();

                                this.Hide();
                                frm.Show();
                            }
                            else
                                MessageBox.Show("接受失败");
                        }
                        catch (Exception ex)
                        {

                            MessageBox.Show(ex.Message);
                        };

                        lo.CloseConnection();
                    }


                }

                else if ((bool)dataGridView1.Rows[e.RowIndex].Cells[0].EditedFormattedValue == false)
                {
                    int result;
                    this.dataGridView1.Rows[e.RowIndex].Cells[0].Value = true;
                    DialogResult dr = MessageBox.Show("确定取消该任务？", "提示", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                    if (dr == System.Windows.Forms.DialogResult.OK)
                    {
                        login lo = new login();
                        string sql = string.Format(@"update orders set d_phone='{0}',o_state='{1}' where r_num='{2}'", user6.userid, 1, dataGridView1.Rows[e.RowIndex].Cells[1].EditedFormattedValue);
                        try
                        {
                            SqlCommand cmd = new SqlCommand(sql, lo.Connection);
                            lo.OpenConnection();
                            result = cmd.ExecuteNonQuery();
                            if (result > 0)
                            {
                                MessageBox.Show("取消成功");
                                receivemission frm = new receivemission();
                                this.Hide();
                                frm.Show();
                            }
                            else
                                MessageBox.Show("取消失败");
                        }
                        catch (Exception ex)
                        {

                            MessageBox.Show(ex.Message);
                        };

                        lo.CloseConnection();

                    }
                }
            }
  
        }

        private void button1_Click(object sender, EventArgs e)
        {
          
           
           // string sqls = string.Format(@"update orders set d_phone='{0}',o_state='{1}' where r_num='{2}'", 0, 0, dataGridView1.Rows[e.RowIndex].Cells[1].EditedFormattedValue);
            Formmain frm = new Formmain();
            frm.Show();
            this.Hide();
        }

        private void dataGridView1_CurrentCellChanged(object sender, EventArgs e)
        {

        }
    }
}
