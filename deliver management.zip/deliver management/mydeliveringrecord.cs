﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace deliver_management
{
    public partial class mydeliveringrecord : Form
    {
        public user user5;
        DataTable dt;
        SqlConnection conn;
        public mydeliveringrecord()
        {
            InitializeComponent();
        }

        private void dataGridViewrecord_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void mydeliveringrecord_Load(object sender, EventArgs e)
        {
            string sql = string.Format ("select r_num as 取件号 ,d_address as 快递点 ,r_address as 收货地址 ,o_describe as 备注, r_datetime as 截止时间, o_price AS 金额 from orders where m_phone='{0}'",user5.userid);
            SqlConnectionStringBuilder scsb = new SqlConnectionStringBuilder();
            scsb.DataSource = "192.168.43.110";
            scsb.UserID = "sa";
            scsb.Password = "123";
            scsb.InitialCatalog = "delivery";
            SqlConnection conn = new SqlConnection(scsb.ToString());
            if (conn.State == System.Data.ConnectionState.Closed) conn.Open();
            // string sql = "select * from orders";
            SqlDataAdapter da = new SqlDataAdapter(sql, conn);
            DataSet ds = new DataSet();
            da.Fill(ds, "orders");
            // this. fliter(0);
            //  dataGridViewrecord.DataSource = ds;
            //dataGridViewrecord .DataMember = "orders";
            dt = ds.Tables["orders"];
            dataGridViewrecord.DataSource = dt.DefaultView;
        }
        
        private void button1_Click(object sender, EventArgs e)
        {//存储加载以来的所有更改
            string sql = string.Empty;
            DataTable ch= dt.GetChanges();
          foreach (  DataRow dr in ch.Rows)
            {
                if (dr.RowState == System.Data.DataRowState.Deleted)
                {
                    sql=@"delete from orders where r_num='"+dr["取件号",DataRowVersion.Original].ToString()+"'";
                }
            }
            SqlCommand cmd = new SqlCommand(sql, conn);
            Formmain frm = new Formmain();
            frm.Show();
            this.Hide();
        }
    }
}
